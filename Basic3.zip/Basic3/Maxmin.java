import java.util.Scanner;
public class Maxmin {
	public static void main(String args [])
	{
		Scanner in=new Scanner(System.in);
		System.out.print("Enter the elements ");
		int elements =in.nextInt();
		int[]array=new int[elements];
		int max  = array[0];
		int min =array[0];
		System.out.print("Enter the value ");
		for(int i=0; i<elements;i++)
		{
		array[i] = in.nextInt();
		if(array[i]>max)
		{
		max = array[i];
		}
		if(array[i]<min)
		{
		min = array[i];
		}
		}
		System.out.print("the maximum number "+max);
	
		System.out.print("the minimum number "+min);
	}
}

