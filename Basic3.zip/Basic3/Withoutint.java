import java.util.*;
public class Withoutint {
	public static void main(String args[])
	{
		int [] array_nums={78, 67, 33, 99, -65};
		System.out.println("real array " +Arrays.toString(array_nums));
		System.out.println("result " +test(array_nums));
	}
	public static boolean test(int[] numbers)
	{
		for (int number : numbers)
		{
		if (number == 0 || number == -1)
		{
	        return false;
		}
		}
		return true;
	}
}

