import java.util.Scanner;
public class Celsius{
public static void main(String args[])
{
double c,f;
Scanner input = new Scanner(System.in);
c=input.nextDouble();
f=((9/5)*c)+32;
System.out.println(f);
}
}

