import java.util.*;
class sample{
	public static void main(String args[])
	{
		Scanner input=new Scanner(System.in);
		int num=input.nextInt();
		System.out.println("squ"+Math.pow (num,2));
		System.out.println("cube"+Math.pow(num,3));
		System.out.println("fourth"+Math.pow(num,4));



	}
}

