import java.util.Scanner;
public class PN{
	public static void main(String args[])
	{
		Scanner pc=new Scanner(System.in);
		System.out.println("enter the value");
		int input=pc.nextInt();
		if (input>0)
		{
			System.out.println("input value is positive");
		}
		else 
		{
			System.out.println("input value is negative");
		}
			
		}
	}


