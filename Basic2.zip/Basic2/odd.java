import java.util.Scanner;
class odd{
	public static void main(String args[])
	{
		int i,number;
		System.out.println("the odd numbers 1 to" );
		for(i=1;i<=number;i++)
		{
			if(i%2!=0)
			{
				System.out.println(i+"");
			}
		}
	}
}

