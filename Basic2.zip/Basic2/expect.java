import java.util.Scanner;
class expect{
	public static void main(String args[])
	{
	Scanner in=new Scanner(System.in);
	int a=1;
	int b=0;
	float m=in.nextFloat();
	if (m>0)
	{
		System.out.println("m value="+m);
		System.out.println(a);
	}
	else {
		System.out.println(b);
	}
}
}



