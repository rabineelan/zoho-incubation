import java.util.Scanner;
public class avg{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int math=0;
		int avg=0;
		System.out.println("input five number");
		for(int i=1; i<=5; i++)
		{
			int num= sc.nextInt();
			math+=num;
		}
		System.out.println("the sum given number"+math);
		avg=math/6;
		System.out.println("the avg given number"+avg);
	}
}

